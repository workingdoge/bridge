package bridge.verifier

import rego.v1

default allow := false
default burn := false
default effective_authority_or_null := null

# Main decision envelope.
decision := {
	"effect": "burn",
	"allow": false,
	"burn": true,
	"trace": object.get(input.witness, "trace", null),
	"jti": object.get(input.witness, "jti", null),
	"deny_reasons": [],
	"burn_reasons": burn_reason_list,
	"effective_authority": effective_authority_or_null,
} if {
	burn
}

decision := {
	"effect": "accept",
	"allow": true,
	"burn": false,
	"trace": object.get(input.witness, "trace", null),
	"jti": object.get(input.witness, "jti", null),
	"deny_reasons": [],
	"burn_reasons": [],
	"effective_authority": effective_authority_or_null,
} if {
	not burn
	allow
}

decision := {
	"effect": "deny",
	"allow": false,
	"burn": false,
	"trace": object.get(input.witness, "trace", null),
	"jti": object.get(input.witness, "jti", null),
	"deny_reasons": deny_reason_list,
	"burn_reasons": [],
	"effective_authority": effective_authority_or_null,
} if {
	not burn
	not allow
}

allow if {
	not burn
	count(deny_reason_list) == 0
	effective_authority
}

burn if {
	count(burn_reason_list) > 0
}

effective_authority_or_null := effective_authority if {
	effective_authority
}

deny_reason_list := sort([r | deny_reasons contains r])
burn_reason_list := sort([r | burn_reasons contains r])

#
# Burn triggers
#

burn_reasons contains "BRIDGE_HOST_ATTESTATION_FAILED" if {
	object.get(object.get(input, "events", {}), "bridge_host_attestation_failed", false)
}

burn_reasons contains "ISSUER_COMPROMISE_DETECTED" if {
	object.get(object.get(input, "events", {}), "issuer_compromise_detected", false)
}

burn_reasons contains "AUDIT_TAMPER_DETECTED" if {
	object.get(object.get(input, "events", {}), "audit_tamper_detected", false)
}

burn_reasons contains "CANARY_OR_HONEY_CREDENTIAL_ACTIVATED" if {
	object.get(object.get(input, "events", {}), "canary_or_honey_credential_activated", false)
}

burn_reasons contains "CONTROLLED_RELEASE_POLICY_BYPASS_DETECTED" if {
	object.get(object.get(input, "events", {}), "controlled_release_policy_bypass_detected", false)
}

burn_reasons contains "POLICY_HASH_MISMATCH" if {
	object.get(object.get(input, "events", {}), "policy_hash_mismatch", false)
}

#
# Deny pipeline translated from verifier-rules.yaml
#

deny_reasons contains "INVALID_SCHEMA" if {
	object.get(object.get(input, "preflight", {}), "schema_valid", false) == false
}

deny_reasons contains "TIME_SOURCE_UNAVAILABLE" if {
	object.get(object.get(input, "runtime_request", {}), "time_source_ok", false) == false
}

deny_reasons contains "BAD_SIGNATURE" if {
	object.get(object.get(input, "preflight", {}), "signature_valid", false) == false
}

deny_reasons contains "REVOKED" if {
	object.get(object.get(input, "preflight", {}), "issuer_not_revoked", false) == false
}

deny_reasons contains "REVOKED" if {
	object.get(object.get(input, "preflight", {}), "jti_not_revoked", false) == false
}

deny_reasons contains "TIME_WINDOW" if {
	not time_window_ok
}

deny_reasons contains "REPLAY" if {
	object.get(object.get(input, "preflight", {}), "replay_cache_absent", false) == false
}

deny_reasons contains "WRONG_AUDIENCE" if {
	object.get(input.witness, "audience", "") != object.get(input.runtime_request, "verifier_id", "")
}

deny_reasons contains "POP_FAILED" if {
	object.get(object.get(input, "preflight", {}), "pop_valid", false) == false
}

deny_reasons contains "ASSERTION_INJECTION_RISK" if {
	object.get(object.get(input, "runtime_request", {}), "rp_initiated", false) == false
}

deny_reasons contains "POSTURE_MISMATCH" if {
	object.get(object.get(input, "preflight", {}), "posture_match", false) == false
}

deny_reasons contains "IDENTITY_POLICY" if {
	not identity_policy_ok
}

deny_reasons contains "SCOPE_MISMATCH" if {
	not scope_ok
}

deny_reasons contains "DOMAIN_MISMATCH" if {
	object.get(input.witness, "domain", "") != object.get(input.runtime_request, "source_domain", "")
}

deny_reasons contains "MODE_DISALLOWS_VERB" if {
	not mode_allows_verb
}

deny_reasons contains "LABEL_POLICY" if {
	not label_flow_ok
}

deny_reasons contains "APPROVALS_INSUFFICIENT" if {
	object.get(input.witness, "approval_mode", "none") != "none"
	not approvals_ok
}

deny_reasons contains "NO_CONTROLLED_RELEASE_WITNESS" if {
	object.get(object.get(input, "runtime_request", {}), "cross_domain", false)
	object.get(input.witness, "witness_type", "") != "controlled-release"
}

deny_reasons contains "RELEASE_BINDING_MISMATCH" if {
	object.get(input.witness, "witness_type", "") == "controlled-release"
	not release_binding_ok
}

deny_reasons contains "RELEASE_POLICY" if {
	object.get(input.witness, "witness_type", "") == "controlled-release"
	not release_policy_ok
}

deny_reasons contains "MEET_FAILED" if {
	not effective_authority
}

deny_reasons contains "NONLOCAL_MATERIALIZATION" if {
	object.get(object.get(input, "preflight", {}), "materialize_only_at_execution_leaf", false) == false
}

deny_reasons contains "EVIDENCE_EMIT_FAILURE" if {
	object.get(object.get(input, "preflight", {}), "evidence_emit_ok", false) == false
}

#
# Helper predicates
#

time_window_ok if {
	now_ns := time.parse_rfc3339_ns(object.get(input.runtime_request, "now", "1970-01-01T00:00:00Z"))
	nbf_ns := time.parse_rfc3339_ns(object.get(input.witness, "nbf", "9999-12-31T23:59:59Z"))
	exp_ns := time.parse_rfc3339_ns(object.get(input.witness, "exp", "1970-01-01T00:00:00Z"))
	nbf_ns <= now_ns
	now_ns <= exp_ns
	ttl_limit := object.get(data.bridge.policy.ttl_by_verb_class_s, object.get(object.get(input.witness, "constraints", {}), "verb_class", ""), 0)
	ttl_limit > 0
	window_s := (exp_ns - nbf_ns) / 1000000000
	window_s <= ttl_limit
	object.get(input.witness, "ttl_s", 0) <= ttl_limit
}

identity_policy_ok if {
	object.get(object.get(input, "preflight", {}), "subject_allowed", false)
	delegation_ok
}

delegation_ok if {
	object.get(input.witness, "act_for", "") == ""
}

delegation_ok if {
	object.get(input.witness, "act_for", "") != ""
	object.get(object.get(input, "preflight", {}), "delegated_actor_allowed", false)
}

scope_ok if {
	object.get(input.witness, "tool", "") == object.get(input.runtime_request, "requested_tool", "")
	object.get(input.witness, "resource", "") == object.get(input.runtime_request, "requested_resource", "")
}

mode_allows_verb if {
	verb := object.get(object.get(input.witness, "constraints", {}), "verb_class", "")
	allowed := object.get(object.get(data.bridge.policy.mode_policy, object.get(input.runtime_request, "current_mode", ""), {}), "allow_verb_classes", [])
	verb in allowed
}

label_flow_ok if {
	object.get(object.get(input, "runtime_request", {}), "cross_domain", false) == false
}

label_flow_ok if {
	object.get(object.get(input, "runtime_request", {}), "cross_domain", false)
	dest := object.get(input.runtime_request, "destination_domain", "")
	dest != ""
	allowed_dests := object.get(object.get(input.runtime_request, "resource_policy", {}), "allowed_destination_domains", object.get(object.get(data.bridge.release_policy, "allowed_destination_domains", {}), object.get(input.witness, "domain", ""), []))
	dest in allowed_dests
}

approvals_ok if {
	mode := object.get(input.witness, "approval_mode", "none")
	mode == "single"
	object.get(object.get(input.witness, "approval_evidence", {}), "quorum", 0) >= 1
	count(object.get(object.get(input.witness, "approval_evidence", {}), "approvers", [])) >= 1
}

approvals_ok if {
	mode := object.get(input.witness, "approval_mode", "none")
	mode == "dual"
	object.get(object.get(input.witness, "approval_evidence", {}), "quorum", 0) >= 2
	count(object.get(object.get(input.witness, "approval_evidence", {}), "approvers", [])) >= 2
	required_roles := {r | some r in data.bridge.release_policy.required_dual_roles}
	actual_roles := {r |
		some a in object.get(object.get(input.witness, "approval_evidence", {}), "approvers", [])
		r := object.get(a, "role", "")
		r != ""
	}
	count(required_roles - actual_roles) == 0
}

approvals_ok if {
	object.get(input.witness, "approval_mode", "none") == "none"
}

release_binding_ok if {
	dest := object.get(input.runtime_request, "destination_domain", "")
	dest != ""
	object.get(object.get(input.witness, "release", {}), "destination_domain", "") == dest
	object.get(input.runtime_request, "payload_hash", "") == object.get(object.get(object.get(input.witness, "release", {}), "content_binding", {}), "value", "")
}

release_policy_ok if {
	basis := object.get(object.get(input.witness, "release", {}), "release_basis", "")
	basis in data.bridge.release_policy.allowed_release_bases
	object.get(object.get(input, "preflight", {}), "release_basis_allowed", false)
	object.get(object.get(input, "preflight", {}), "release_review_chain_complete", false)
}

#
# Effective authority meet
#

effective_authority := {
	"tool": object.get(input.runtime_request, "requested_tool", ""),
	"resource": object.get(input.runtime_request, "requested_resource", ""),
	"conf_label": conf_label_meet,
	"integ_label": integ_label_meet,
	"ttl_s": ttl_meet,
	"egress_policy": egress_meet,
	"output_policy": output_policy_meet,
	"approval_mode": approval_mode_meet,
	"constraints": constraint_meet,
} if {
	scope_ok
	conf_label_meet
	integ_label_meet
	ttl_meet > 0
	egress_meet_ok
	output_policy_meet
	approval_mode_meet != ""
	constraint_meet
}

conf_label_meet := {
	"level": more_restrictive_conf_level(object.get(object.get(input.witness, "conf_label", {}), "level", "public"), object.get(object.get(input.runtime_request, "resource_policy", {}), "required_conf_level", object.get(object.get(input.witness, "conf_label", {}), "level", "public"))),
	"compartments": sorted_intersection(
		object.get(object.get(input.witness, "conf_label", {}), "compartments", []),
		object.get(object.get(input.runtime_request, "resource_policy", {}), "required_compartments", object.get(object.get(input.witness, "conf_label", {}), "compartments", [])),
	),
	"tags": sorted_intersection(
		object.get(object.get(input.witness, "conf_label", {}), "tags", []),
		object.get(object.get(input.runtime_request, "resource_policy", {}), "required_tags", object.get(object.get(input.witness, "conf_label", {}), "tags", [])),
	),
	"marking": object.get(object.get(input.witness, "conf_label", {}), "marking", ""),
} if {
	object.get(object.get(input.witness, "conf_label", {}), "level", "") != ""
}

integ_label_meet := {
	"level": lower_integrity_level(object.get(object.get(input.witness, "integ_label", {}), "level", "untrusted"), object.get(object.get(input.runtime_request, "resource_policy", {}), "required_integ_level", object.get(object.get(input.witness, "integ_label", {}), "level", "untrusted"))),
	"tags": sorted_intersection(
		object.get(object.get(input.witness, "integ_label", {}), "tags", []),
		object.get(object.get(input.runtime_request, "resource_policy", {}), "required_integ_tags", object.get(object.get(input.witness, "integ_label", {}), "tags", [])),
	),
} if {
	object.get(object.get(input.witness, "integ_label", {}), "level", "") != ""
}

ttl_meet := min([
	object.get(input.witness, "ttl_s", 0),
	object.get(object.get(data.bridge.policy, "ttl_by_verb_class_s", {}), object.get(object.get(input.witness, "constraints", {}), "verb_class", ""), 0),
	object.get(object.get(input.runtime_request, "resource_policy", {}), "max_ttl_s", object.get(input.witness, "ttl_s", 0)),
])

egress_meet_ok if {
	egress_meet.mode == "deny"
}

egress_meet_ok if {
	egress_meet.mode == "allowlist"
	count(object.get(egress_meet, "destinations", [])) > 0
}

egress_meet := {"mode": "deny"} if {
	object.get(object.get(input.witness, "egress_policy", {}), "mode", "deny") == "deny"
}

egress_meet := {"mode": "deny"} if {
	object.get(object.get(input.runtime_request, "resource_policy", {}), "egress_mode", "allowlist") == "deny"
}

egress_meet := {"mode": "allowlist", "destinations": destinations} if {
	object.get(object.get(input.witness, "egress_policy", {}), "mode", "deny") == "allowlist"
	object.get(object.get(input.runtime_request, "resource_policy", {}), "egress_mode", "allowlist") == "allowlist"
	wd := object.get(object.get(input.witness, "egress_policy", {}), "destinations", [])
	rd := object.get(object.get(input.runtime_request, "resource_policy", {}), "egress_allowlist", wd)
	destinations := sorted_intersection(wd, rd)
}

output_policy_meet := {
	"redaction_profile": object.get(object.get(input.runtime_request, "resource_policy", {}), "required_redaction_profile", object.get(object.get(input.witness, "output_policy", {}), "redaction_profile", "")),
	"max_response_bytes": min([
		object.get(object.get(input.witness, "output_policy", {}), "max_response_bytes", 0),
		object.get(object.get(input.runtime_request, "resource_policy", {}), "max_response_bytes", object.get(object.get(input.witness, "output_policy", {}), "max_response_bytes", 0)),
	]),
	"allow_secrets_in_output": false,
	"return_to_model": return_to_model_meet,
	"strip_html": strip_html_meet,
	"classify_output": classify_output_meet,
} if {
	object.get(object.get(input.witness, "output_policy", {}), "allow_secrets_in_output", true) == false
}

default return_to_model_meet := false

return_to_model_meet if {
	object.get(object.get(input.witness, "output_policy", {}), "return_to_model", false)
	object.get(object.get(input.runtime_request, "resource_policy", {}), "return_to_model_allowed", object.get(object.get(input.witness, "output_policy", {}), "return_to_model", false))
}

default strip_html_meet := false

strip_html_meet if {
	object.get(object.get(input.witness, "output_policy", {}), "strip_html", false)
}

strip_html_meet if {
	object.get(object.get(input.runtime_request, "resource_policy", {}), "strip_html", false)
}

default classify_output_meet := false

classify_output_meet if {
	object.get(object.get(input.witness, "output_policy", {}), "classify_output", false)
}

classify_output_meet if {
	object.get(object.get(input.runtime_request, "resource_policy", {}), "classify_output", false)
}

approval_mode_meet := data.bridge.policy.approval_mode_order[idx] if {
	w_idx := approval_rank(object.get(input.witness, "approval_mode", "none"))
	r_idx := approval_rank(object.get(object.get(input.runtime_request, "resource_policy", {}), "required_approval_mode", object.get(input.witness, "approval_mode", "none")))
	idx := max([w_idx, r_idx])
}

constraint_meet := {
	"verb_class": object.get(object.get(input.witness, "constraints", {}), "verb_class", ""),
	"rows_max": min([
		object.get(object.get(input.witness, "constraints", {}), "rows_max", 10000000),
		object.get(object.get(input.runtime_request, "resource_policy", {}), "rows_max", object.get(object.get(input.witness, "constraints", {}), "rows_max", 10000000)),
	]),
	"max_bytes": min([
		object.get(object.get(input.witness, "constraints", {}), "max_bytes", 1073741824),
		object.get(object.get(input.runtime_request, "resource_policy", {}), "max_bytes", object.get(object.get(input.witness, "constraints", {}), "max_bytes", 1073741824)),
	]),
	"rate_per_min": min([
		object.get(object.get(input.witness, "constraints", {}), "rate_per_min", 1000000),
		object.get(object.get(input.runtime_request, "resource_policy", {}), "rate_per_min", object.get(object.get(input.witness, "constraints", {}), "rate_per_min", 1000000)),
	]),
	"single_use": single_use_meet,
	"human_review_required": human_review_required_meet,
	"max_secret_materializations": min([
		object.get(object.get(input.witness, "constraints", {}), "max_secret_materializations", 0),
		object.get(object.get(input.runtime_request, "resource_policy", {}), "max_secret_materializations", object.get(object.get(input.witness, "constraints", {}), "max_secret_materializations", 0)),
	]),
} if {
	object.get(object.get(input.witness, "constraints", {}), "verb_class", "") != ""
}

default single_use_meet := false

single_use_meet if {
	object.get(object.get(input.witness, "constraints", {}), "single_use", false)
}

single_use_meet if {
	object.get(object.get(input.runtime_request, "resource_policy", {}), "require_single_use", false)
}

default human_review_required_meet := false

human_review_required_meet if {
	object.get(object.get(input.witness, "constraints", {}), "human_review_required", false)
}

human_review_required_meet if {
	object.get(object.get(input.runtime_request, "resource_policy", {}), "human_review_required", false)
}

#
# Utility functions
#

sorted_intersection(a, b) := sort([x | some x in a; x in b])

approval_rank(mode) := idx if {
	some i
	data.bridge.policy.approval_mode_order[i] == mode
	idx := i
}

conf_rank(level) := idx if {
	some i
	data.bridge.policy.label_lattice.confidentiality_order[i] == level
	idx := i
}

integ_rank(level) := idx if {
	some i
	data.bridge.policy.label_lattice.integrity_order[i] == level
	idx := i
}

more_restrictive_conf_level(a, b) := data.bridge.policy.label_lattice.confidentiality_order[idx] if {
	idx := max([conf_rank(a), conf_rank(b)])
}

lower_integrity_level(a, b) := data.bridge.policy.label_lattice.integrity_order[idx] if {
	idx := min([integ_rank(a), integ_rank(b)])
}
