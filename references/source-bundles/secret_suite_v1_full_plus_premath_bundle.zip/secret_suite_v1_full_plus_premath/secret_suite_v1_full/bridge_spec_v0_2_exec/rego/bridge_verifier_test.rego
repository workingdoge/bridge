package bridge.verifier_test

import rego.v1
import data.bridge.verifier

authority_input := {
  "events": {},
  "preflight": {
    "delegated_actor_allowed": true,
    "evidence_emit_ok": true,
    "issuer_not_revoked": true,
    "jti_not_revoked": true,
    "materialize_only_at_execution_leaf": true,
    "pop_valid": true,
    "posture_match": true,
    "release_basis_allowed": true,
    "release_review_chain_complete": true,
    "replay_cache_absent": true,
    "schema_valid": true,
    "signature_valid": true,
    "subject_allowed": true
  },
  "runtime_request": {
    "attestation_snapshot": {
      "digest": "99887766554433221100ffeeddccbbaa99887766554433221100ffeeddccbbaa",
      "issued_at": "2026-04-11T13:59:40Z"
    },
    "cross_domain": false,
    "current_mode": "normal",
    "destination_domain": "acme.prod.analytics",
    "now": "2026-04-11T14:00:30Z",
    "payload_hash": "",
    "pop_proof": {
      "kind": "signed-nonce",
      "verified": true
    },
    "requested_resource": "postgres://analytics/reporting",
    "requested_tool": "db.query.readonly",
    "resource_policy": {
      "allowed_destination_domains": [],
      "classify_output": true,
      "egress_allowlist": [
        "postgres://analytics/reporting"
      ],
      "egress_mode": "allowlist",
      "human_review_required": false,
      "max_bytes": 65536,
      "max_response_bytes": 65536,
      "max_secret_materializations": 1,
      "max_ttl_s": 180,
      "rate_per_min": 5,
      "require_single_use": false,
      "required_approval_mode": "none",
      "required_compartments": [
        "finance"
      ],
      "required_conf_level": "internal",
      "required_integ_level": "asserted",
      "required_integ_tags": [
        "signed"
      ],
      "required_redaction_profile": "finance-summary-v1",
      "required_tags": [
        "reporting"
      ],
      "return_to_model_allowed": true,
      "rows_max": 1000,
      "strip_html": true
    },
    "revocation_snapshot": {
      "issuers": [],
      "jtis": []
    },
    "rp_initiated": true,
    "session_nonce": "n-9Q4zprA7XCeM2sL",
    "source_domain": "acme.prod.analytics",
    "time_source_ok": true,
    "verifier_id": "tusk-broker://us-east-1/bridge"
  },
  "witness": {
    "act_for": "user:alice@example.com",
    "approval_mode": "none",
    "audience": "tusk-broker://us-east-1/bridge",
    "conf_label": {
      "compartments": [
        "finance"
      ],
      "level": "restricted",
      "marking": "internal-need-to-know",
      "tags": [
        "reporting"
      ]
    },
    "connector_digest": {
      "alg": "sha-256",
      "value": "beadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbead"
    },
    "constraints": {
      "human_review_required": false,
      "max_bytes": 1048576,
      "max_secret_materializations": 1,
      "rate_per_min": 10,
      "rows_max": 5000,
      "single_use": true,
      "verb_class": "read"
    },
    "domain": "acme.prod.analytics",
    "egress_policy": {
      "destinations": [
        "postgres://analytics/reporting"
      ],
      "mode": "allowlist"
    },
    "exp": "2026-04-11T14:02:00Z",
    "integ_label": {
      "level": "attested",
      "tags": [
        "signed",
        "measured-boot"
      ]
    },
    "iss": "bridge-issuer.core",
    "issuer_alg": "EdDSA",
    "jti": "464e6650-b1b0-41f9-89da-47b9b43e8c2b",
    "model_digest": {
      "alg": "sha-256",
      "value": "8be4a6073ef1f3e3e9b9ce2e5a4cf8a2761ed01b2adca99ec53b8f0bd8d9f111"
    },
    "nbf": "2026-04-11T14:00:00Z",
    "output_policy": {
      "allow_secrets_in_output": false,
      "classify_output": true,
      "max_response_bytes": 65536,
      "redaction_profile": "finance-summary-v1",
      "return_to_model": true,
      "strip_html": true
    },
    "pop_key": {
      "binding": "spki-sha256",
      "kid": "run-2026-04-11-001",
      "nonce": "n-9Q4zprA7XCeM2sL",
      "proof_method": "signed-nonce",
      "value": "sha256-2d3e4f5a6b7c8d9e00112233445566778899aabbccddeeff0011223344556677"
    },
    "posture_digest": {
      "alg": "sha-256",
      "issued_at": "2026-04-11T13:59:40Z",
      "value": "99887766554433221100ffeeddccbbaa99887766554433221100ffeeddccbbaa"
    },
    "purpose": "weekly revenue summary",
    "resource": "postgres://analytics/reporting",
    "sig": {
      "alg": "EdDSA",
      "key_epoch": "2026Q2",
      "key_id": "bridge-issuer-2026-q2",
      "value": "dGVzdC1zaWduYXR1cmUtYmFzZTY0dXJsLXN0dWI"
    },
    "sub": "spiffe://acme/agents/reporting-worker",
    "tool": "db.query.readonly",
    "trace": "ca14e9e0-1c8c-40bd-bc53-5d01e4876de8",
    "ttl_s": 120,
    "version": "0.2",
    "witness_type": "authority"
  }
}

scope_mismatch_input := {
  "events": {},
  "preflight": {
    "delegated_actor_allowed": true,
    "evidence_emit_ok": true,
    "issuer_not_revoked": true,
    "jti_not_revoked": true,
    "materialize_only_at_execution_leaf": true,
    "pop_valid": true,
    "posture_match": true,
    "release_basis_allowed": true,
    "release_review_chain_complete": true,
    "replay_cache_absent": true,
    "schema_valid": true,
    "signature_valid": true,
    "subject_allowed": true
  },
  "runtime_request": {
    "attestation_snapshot": {
      "digest": "99887766554433221100ffeeddccbbaa99887766554433221100ffeeddccbbaa",
      "issued_at": "2026-04-11T13:59:40Z"
    },
    "cross_domain": false,
    "current_mode": "normal",
    "destination_domain": "acme.prod.analytics",
    "now": "2026-04-11T14:00:30Z",
    "payload_hash": "",
    "pop_proof": {
      "kind": "signed-nonce",
      "verified": true
    },
    "requested_resource": "postgres://analytics/other",
    "requested_tool": "db.query.readonly",
    "resource_policy": {
      "allowed_destination_domains": [],
      "classify_output": true,
      "egress_allowlist": [
        "postgres://analytics/reporting"
      ],
      "egress_mode": "allowlist",
      "human_review_required": false,
      "max_bytes": 65536,
      "max_response_bytes": 65536,
      "max_secret_materializations": 1,
      "max_ttl_s": 180,
      "rate_per_min": 5,
      "require_single_use": false,
      "required_approval_mode": "none",
      "required_compartments": [
        "finance"
      ],
      "required_conf_level": "internal",
      "required_integ_level": "asserted",
      "required_integ_tags": [
        "signed"
      ],
      "required_redaction_profile": "finance-summary-v1",
      "required_tags": [
        "reporting"
      ],
      "return_to_model_allowed": true,
      "rows_max": 1000,
      "strip_html": true
    },
    "revocation_snapshot": {
      "issuers": [],
      "jtis": []
    },
    "rp_initiated": true,
    "session_nonce": "n-9Q4zprA7XCeM2sL",
    "source_domain": "acme.prod.analytics",
    "time_source_ok": true,
    "verifier_id": "tusk-broker://us-east-1/bridge"
  },
  "witness": {
    "act_for": "user:alice@example.com",
    "approval_mode": "none",
    "audience": "tusk-broker://us-east-1/bridge",
    "conf_label": {
      "compartments": [
        "finance"
      ],
      "level": "restricted",
      "marking": "internal-need-to-know",
      "tags": [
        "reporting"
      ]
    },
    "connector_digest": {
      "alg": "sha-256",
      "value": "beadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbead"
    },
    "constraints": {
      "human_review_required": false,
      "max_bytes": 1048576,
      "max_secret_materializations": 1,
      "rate_per_min": 10,
      "rows_max": 5000,
      "single_use": true,
      "verb_class": "read"
    },
    "domain": "acme.prod.analytics",
    "egress_policy": {
      "destinations": [
        "postgres://analytics/reporting"
      ],
      "mode": "allowlist"
    },
    "exp": "2026-04-11T14:02:00Z",
    "integ_label": {
      "level": "attested",
      "tags": [
        "signed",
        "measured-boot"
      ]
    },
    "iss": "bridge-issuer.core",
    "issuer_alg": "EdDSA",
    "jti": "464e6650-b1b0-41f9-89da-47b9b43e8c2b",
    "model_digest": {
      "alg": "sha-256",
      "value": "8be4a6073ef1f3e3e9b9ce2e5a4cf8a2761ed01b2adca99ec53b8f0bd8d9f111"
    },
    "nbf": "2026-04-11T14:00:00Z",
    "output_policy": {
      "allow_secrets_in_output": false,
      "classify_output": true,
      "max_response_bytes": 65536,
      "redaction_profile": "finance-summary-v1",
      "return_to_model": true,
      "strip_html": true
    },
    "pop_key": {
      "binding": "spki-sha256",
      "kid": "run-2026-04-11-001",
      "nonce": "n-9Q4zprA7XCeM2sL",
      "proof_method": "signed-nonce",
      "value": "sha256-2d3e4f5a6b7c8d9e00112233445566778899aabbccddeeff0011223344556677"
    },
    "posture_digest": {
      "alg": "sha-256",
      "issued_at": "2026-04-11T13:59:40Z",
      "value": "99887766554433221100ffeeddccbbaa99887766554433221100ffeeddccbbaa"
    },
    "purpose": "weekly revenue summary",
    "resource": "postgres://analytics/reporting",
    "sig": {
      "alg": "EdDSA",
      "key_epoch": "2026Q2",
      "key_id": "bridge-issuer-2026-q2",
      "value": "dGVzdC1zaWduYXR1cmUtYmFzZTY0dXJsLXN0dWI"
    },
    "sub": "spiffe://acme/agents/reporting-worker",
    "tool": "db.query.readonly",
    "trace": "ca14e9e0-1c8c-40bd-bc53-5d01e4876de8",
    "ttl_s": 120,
    "version": "0.2",
    "witness_type": "authority"
  }
}

release_input := {
  "events": {},
  "preflight": {
    "delegated_actor_allowed": true,
    "evidence_emit_ok": true,
    "issuer_not_revoked": true,
    "jti_not_revoked": true,
    "materialize_only_at_execution_leaf": true,
    "pop_valid": true,
    "posture_match": true,
    "release_basis_allowed": true,
    "release_review_chain_complete": true,
    "replay_cache_absent": true,
    "schema_valid": true,
    "signature_valid": true,
    "subject_allowed": true
  },
  "runtime_request": {
    "attestation_snapshot": {
      "digest": "abcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcd",
      "issued_at": "2026-04-11T14:59:55Z"
    },
    "cross_domain": true,
    "current_mode": "normal",
    "destination_domain": "acme.exec.readonly",
    "now": "2026-04-11T15:00:30Z",
    "payload_hash": "4c3f2a1b0e9d8c7b6a59687766554433221100ffeeddccbbaa99887766554433",
    "pop_proof": {
      "kind": "mtls",
      "verified": true
    },
    "requested_resource": "report://weekly-finance-summary/2026-W15",
    "requested_tool": "release.export",
    "resource_policy": {
      "allowed_destination_domains": [
        "acme.exec.readonly"
      ],
      "classify_output": true,
      "egress_allowlist": [
        "report://executive-portal/inbox"
      ],
      "egress_mode": "allowlist",
      "human_review_required": false,
      "max_bytes": 262144,
      "max_response_bytes": 262144,
      "max_secret_materializations": 0,
      "max_ttl_s": 60,
      "rate_per_min": 2,
      "require_single_use": true,
      "required_approval_mode": "dual",
      "required_compartments": [
        "finance"
      ],
      "required_conf_level": "internal",
      "required_integ_level": "asserted",
      "required_integ_tags": [
        "reviewed",
        "signed"
      ],
      "required_redaction_profile": "exec-summary-v2",
      "return_to_model_allowed": false,
      "strip_html": true
    },
    "revocation_snapshot": {
      "issuers": [],
      "jtis": []
    },
    "rp_initiated": true,
    "session_nonce": "",
    "source_domain": "acme.prod.finance",
    "time_source_ok": true,
    "verifier_id": "tusk-broker://us-east-1/bridge"
  },
  "witness": {
    "act_for": "user:alice@example.com",
    "approval_evidence": {
      "approvers": [
        {
          "id": "user:analyst1@example.com",
          "role": "finance-reviewer",
          "signature_ref": "sigstore://release-approval/1",
          "time": "2026-04-11T14:58:20Z"
        },
        {
          "id": "user:security2@example.com",
          "role": "security-reviewer",
          "signature_ref": "sigstore://release-approval/2",
          "time": "2026-04-11T14:58:50Z"
        }
      ],
      "quorum": 2,
      "reason": "Approved sanitized release to executive readonly domain.",
      "ticket": "REL-2026-0411-01"
    },
    "approval_mode": "dual",
    "audience": "tusk-broker://us-east-1/bridge",
    "conf_label": {
      "compartments": [
        "finance"
      ],
      "level": "restricted"
    },
    "constraints": {
      "human_review_required": false,
      "max_bytes": 262144,
      "max_secret_materializations": 0,
      "single_use": true,
      "verb_class": "release"
    },
    "domain": "acme.prod.finance",
    "egress_policy": {
      "destinations": [
        "report://executive-portal/inbox"
      ],
      "mode": "allowlist"
    },
    "exp": "2026-04-11T15:01:00Z",
    "integ_label": {
      "level": "verified",
      "tags": [
        "reviewed",
        "signed"
      ]
    },
    "iss": "bridge-issuer.core",
    "issuer_alg": "EdDSA",
    "jti": "264b7273-6fbe-4a50-8263-215744820bdb",
    "nbf": "2026-04-11T15:00:00Z",
    "output_policy": {
      "allow_secrets_in_output": false,
      "classify_output": true,
      "max_response_bytes": 262144,
      "redaction_profile": "exec-summary-v2",
      "return_to_model": false,
      "strip_html": true
    },
    "pop_key": {
      "binding": "mtls-cert-sha256",
      "kid": "releaser-cert-2026-04",
      "proof_method": "mtls",
      "value": "sha256-efefefefefefefefefefefefefefefefefefefefefefefefefefefefefefefef"
    },
    "posture_digest": {
      "alg": "sha-256",
      "issued_at": "2026-04-11T14:59:55Z",
      "value": "abcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcd"
    },
    "purpose": "executive summary release",
    "release": {
      "automated_releaser_id": "releaser:exec-summary-v2",
      "chain_of_custody_refs": [
        "ticket:REL-2026-0411-01",
        "artifact:exec-summary-v2-sanitizer"
      ],
      "content_binding": {
        "alg": "sha-256",
        "value": "4c3f2a1b0e9d8c7b6a59687766554433221100ffeeddccbbaa99887766554433"
      },
      "destination_domain": "acme.exec.readonly",
      "human_review_required": false,
      "release_basis": "approved sanitizer profile exec-summary-v2",
      "reviewer_ids": [
        "user:analyst1@example.com",
        "user:security2@example.com"
      ],
      "source_domain": "acme.prod.finance"
    },
    "resource": "report://weekly-finance-summary/2026-W15",
    "sig": {
      "alg": "EdDSA",
      "key_epoch": "2026Q2",
      "key_id": "bridge-issuer-2026-q2",
      "value": "bW9jay1yZWxlYXNlLXNpZ25hdHVyZS1iYXNlNjR1cmw"
    },
    "sub": "spiffe://acme/releasers/exec-summary-v2",
    "tool": "release.export",
    "trace": "ccd09add-741b-4a89-86b1-b7af6f2c3868",
    "ttl_s": 60,
    "version": "0.2",
    "witness_type": "controlled-release"
  }
}

burn_input := {
  "events": {
    "audit_tamper_detected": true
  },
  "preflight": {
    "delegated_actor_allowed": true,
    "evidence_emit_ok": true,
    "issuer_not_revoked": true,
    "jti_not_revoked": true,
    "materialize_only_at_execution_leaf": true,
    "pop_valid": true,
    "posture_match": true,
    "release_basis_allowed": true,
    "release_review_chain_complete": true,
    "replay_cache_absent": true,
    "schema_valid": true,
    "signature_valid": true,
    "subject_allowed": true
  },
  "runtime_request": {
    "attestation_snapshot": {
      "digest": "99887766554433221100ffeeddccbbaa99887766554433221100ffeeddccbbaa",
      "issued_at": "2026-04-11T13:59:40Z"
    },
    "cross_domain": false,
    "current_mode": "normal",
    "destination_domain": "acme.prod.analytics",
    "now": "2026-04-11T14:00:30Z",
    "payload_hash": "",
    "pop_proof": {
      "kind": "signed-nonce",
      "verified": true
    },
    "requested_resource": "postgres://analytics/reporting",
    "requested_tool": "db.query.readonly",
    "resource_policy": {
      "allowed_destination_domains": [],
      "classify_output": true,
      "egress_allowlist": [
        "postgres://analytics/reporting"
      ],
      "egress_mode": "allowlist",
      "human_review_required": false,
      "max_bytes": 65536,
      "max_response_bytes": 65536,
      "max_secret_materializations": 1,
      "max_ttl_s": 180,
      "rate_per_min": 5,
      "require_single_use": false,
      "required_approval_mode": "none",
      "required_compartments": [
        "finance"
      ],
      "required_conf_level": "internal",
      "required_integ_level": "asserted",
      "required_integ_tags": [
        "signed"
      ],
      "required_redaction_profile": "finance-summary-v1",
      "required_tags": [
        "reporting"
      ],
      "return_to_model_allowed": true,
      "rows_max": 1000,
      "strip_html": true
    },
    "revocation_snapshot": {
      "issuers": [],
      "jtis": []
    },
    "rp_initiated": true,
    "session_nonce": "n-9Q4zprA7XCeM2sL",
    "source_domain": "acme.prod.analytics",
    "time_source_ok": true,
    "verifier_id": "tusk-broker://us-east-1/bridge"
  },
  "witness": {
    "act_for": "user:alice@example.com",
    "approval_mode": "none",
    "audience": "tusk-broker://us-east-1/bridge",
    "conf_label": {
      "compartments": [
        "finance"
      ],
      "level": "restricted",
      "marking": "internal-need-to-know",
      "tags": [
        "reporting"
      ]
    },
    "connector_digest": {
      "alg": "sha-256",
      "value": "beadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbeadbead"
    },
    "constraints": {
      "human_review_required": false,
      "max_bytes": 1048576,
      "max_secret_materializations": 1,
      "rate_per_min": 10,
      "rows_max": 5000,
      "single_use": true,
      "verb_class": "read"
    },
    "domain": "acme.prod.analytics",
    "egress_policy": {
      "destinations": [
        "postgres://analytics/reporting"
      ],
      "mode": "allowlist"
    },
    "exp": "2026-04-11T14:02:00Z",
    "integ_label": {
      "level": "attested",
      "tags": [
        "signed",
        "measured-boot"
      ]
    },
    "iss": "bridge-issuer.core",
    "issuer_alg": "EdDSA",
    "jti": "464e6650-b1b0-41f9-89da-47b9b43e8c2b",
    "model_digest": {
      "alg": "sha-256",
      "value": "8be4a6073ef1f3e3e9b9ce2e5a4cf8a2761ed01b2adca99ec53b8f0bd8d9f111"
    },
    "nbf": "2026-04-11T14:00:00Z",
    "output_policy": {
      "allow_secrets_in_output": false,
      "classify_output": true,
      "max_response_bytes": 65536,
      "redaction_profile": "finance-summary-v1",
      "return_to_model": true,
      "strip_html": true
    },
    "pop_key": {
      "binding": "spki-sha256",
      "kid": "run-2026-04-11-001",
      "nonce": "n-9Q4zprA7XCeM2sL",
      "proof_method": "signed-nonce",
      "value": "sha256-2d3e4f5a6b7c8d9e00112233445566778899aabbccddeeff0011223344556677"
    },
    "posture_digest": {
      "alg": "sha-256",
      "issued_at": "2026-04-11T13:59:40Z",
      "value": "99887766554433221100ffeeddccbbaa99887766554433221100ffeeddccbbaa"
    },
    "purpose": "weekly revenue summary",
    "resource": "postgres://analytics/reporting",
    "sig": {
      "alg": "EdDSA",
      "key_epoch": "2026Q2",
      "key_id": "bridge-issuer-2026-q2",
      "value": "dGVzdC1zaWduYXR1cmUtYmFzZTY0dXJsLXN0dWI"
    },
    "sub": "spiffe://acme/agents/reporting-worker",
    "tool": "db.query.readonly",
    "trace": "ca14e9e0-1c8c-40bd-bc53-5d01e4876de8",
    "ttl_s": 120,
    "version": "0.2",
    "witness_type": "authority"
  }
}

test_authority_accept if {
	decision := verifier.decision with input as authority_input
	decision.effect == "accept"
	decision.allow
	decision.burn == false
	decision.effective_authority.tool == "db.query.readonly"
	decision.effective_authority.constraints.rows_max == 1000
	decision.effective_authority.output_policy.max_response_bytes == 65536
}

test_scope_mismatch_denied if {
	decision := verifier.decision with input as scope_mismatch_input
	decision.effect == "deny"
	"SCOPE_MISMATCH" in decision.deny_reasons
}

test_release_accept if {
	decision := verifier.decision with input as release_input
	decision.effect == "accept"
	decision.effective_authority.approval_mode == "dual"
	decision.effective_authority.output_policy.return_to_model == false
}

test_burn_overrides_allow if {
	decision := verifier.decision with input as burn_input
	decision.effect == "burn"
	"AUDIT_TAMPER_DETECTED" in decision.burn_reasons
}
