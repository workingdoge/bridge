# Bridge Spec v0.2 Bundle

This bundle turns the bridge/gate concept into a machine-readable starter package.

## Files

- `witness.schema.json` — JSON Schema for the bridge witness.
- `example.authority-witness.json` — sample bounded authority witness.
- `example.controlled-release-witness.json` — sample cross-domain release witness.
- `policy.defaults.yaml` — starter local policy parameters.
- `verifier-rules.yaml` — ordered verifier pipeline and burn triggers.
- `burn-restore-state-machine.yaml` — operational mode machine for `normal`, `degraded`, `safe`, `burn`, and `restoring`.
- `bridge-overlay-profile.json` — OSCAL starter profile for the bridge control set.
- `SHA256SUMS.txt` — integrity hashes for the bundle contents.

## Intended use

Use this as a starting point for:

1. witness minting and redemption,
2. verifier implementation,
3. burn/restore orchestration,
4. control-overlay tailoring.

## Key design choices

- The witness carries *authority*, not long-lived raw secret material.
- Controlled release is a separate witness kind, not an ordinary read/write authority.
- The verifier computes effective authority as a meet, never a union.
- Burn is modeled as a cut in the operational site: no cross-cut mint or redeem survives.
- Restore requires a fresh issuer epoch, fresh attestation, and explicit authorization.

## What still needs local tailoring

- compartment and label taxonomy,
- exact TTLs by verb class,
- attestation freshness thresholds,
- burn propagation SLO,
- approval and release matrices,
- crypto suite and key-epoch handling,
- which control baseline to import above the bridge component.

## Validation notes

The JSON examples are intended to validate against `witness.schema.json`.
The OSCAL profile is a starter profile and may still need organization-specific metadata and tailoring before use in an SSP or assessment package.
